<?php
$connect=mysql_connect("localhost","root","") or die();
		mysql_select_db("phplogin")or die()
?>