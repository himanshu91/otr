<link href="Otr.css" rel="stylesheet" type="text/css" media="screen" />
<div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
				<h2 class="title">Contact Us</h2>
				 <div style="clear: both;">&nbsp;</div>
				
                <p class="meta" style="font-size:13px">
                Contact Us at :-
				<br/>
                <div style="margin-left:100px">
                <p><strong style="color:#82050B">Hitesh Gaba</strong></p>
               <p style="color:#666"><strong style="color:#000">Email :</strong> gaba.hitesh@gmail.com
                <br/><strong style="color:#000">Ph No :</strong> +919549836453
                </p>
                <br/><br />
                <p><strong style="color:#82050B">Jagdish Jat</strong></p>
               <p style="color:#666"><strong style="color:#000">Email :</strong> jagdishjaipur11@rediffmaill.com
                <br/><strong style="color:#000">Ph No :</strong> +919413861116</p>
                 <br/><br />
                <p><strong style="color:#82050B">Himanshu Sharma</strong></p>
               <p style="color:#666"><strong style="color:#000">Email :</strong> himanshu.sharma@gmail.com
                <br/><strong style="color:#000">Ph No :</strong> +917597496888</p></div>
                
                </p>
                
				
                <div style="clear: both;">&nbsp;</div>