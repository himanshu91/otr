<link href="Otr.css" rel="stylesheet" type="text/css" media="screen" />
<div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
				<h2 class="title">Reservation Portal</h2>
                <br />
				<p class="meta">This Portal help you to Reserve your ticket from one station to other the reservation Form is available only For the registered users and not for the non registered users.
It is a secured reservation system Providing users the facility of online ticket reservation. </p> <br />
                <div style="margin-left:150px">
                	
                    <br />
                    <br/ >
                    <table>
					<tr> <form action="inc/reser.php" method="post"> <td><input type="submit" value="Reservation Form"></td> &nbsp;&nbsp; </form>
						 &nbsp;&nbsp;<form action="inc/cancel.php" method="post"> &nbsp;&nbsp;<td><input type="submit" value="Cancellation Form"></td> </form>
					</tr>
				</table>
		 