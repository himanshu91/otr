      			<link href="Otr.css" rel="stylesheet" type="text/css" media="screen" />
				<div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
				<h2 class="title">Indian Railway</h2>
                <br />
				<p class="meta"><strong style="color:82050B" >Indian Railways the Life Line of the country.</strong>
                 has been set up by the Ministry of Railways with the basic purpose of hiving off entire catering and tourism activity of the railways to the new Corporation so as to professionalise and upgrade these services with public-private participation. Rail based Tourism in India will be the specific vehicle for achieving high growth in coordination with state agencies, tour operators, travel agents and the hospitality industry. A dynamic marketing strategy in association with public and private agencies, tour operators, transporters, hoteliers and local tour promoters is on the anvil. Indian Railways span global volumes in hospitality and catering sectors with services provided to 13 million passengers everyday.       
                 <br /><br />          There has been a latent demand in the country for ticket availability at the door-step.This reservation website has been developed to enable reservation of tickets remotly .
                 </p>
				
                <div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
				  
