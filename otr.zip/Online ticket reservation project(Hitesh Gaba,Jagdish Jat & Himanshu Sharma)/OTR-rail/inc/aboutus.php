<link href="Otr.css" rel="stylesheet" type="text/css" media="screen" />
<div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
				<h2 class="title">About Us</h2>
				<p class="meta">
                <br />
                Online ticket reservation system aims at developing a platform for storing the prior information of the availability of tickets and their respective fares between the particular source and destination. It stores the details of the particular stations their arrival and departure timings for the particular Trains. This software has a flexible security function. It aims at providing the users with an interactive user interface to easily accomplish their reservation in a quick manner.
				<ul style="color:#999">
                 <li>The system will allow an existing database which would provide the information of the trains with their respective arrivals and departure details.</li>
                  <li>	The site maintain proper updation of the reserved and available tickets and their conformation on regular basis.</li>
                   <li>The system would allow the online payment of the fares of the ticket via credit, debit, VISA card etc. </li>
                    <li>	The Information Statistics would be maintained in a Secured Database maintained by the authenticated database administrator.</li>
                      
                     <li>The software users would maintain their own account and would be able to accomplish their registration activities on their repective accounts only.</li>
                
                </ul>
                </p>
				
                <div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>