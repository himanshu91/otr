<br/>
<br/>
<h1><span style="color:#85020B">Train Schedule</span></h1>
<br/>
<br/>
<br/>


 <table width="500" height="300" border="1">
  <tr style="color:#85020B">
    <th >S.No.&nbsp;</th>
    <th >NAME&nbsp;</th>

    <th >DEPART&nbsp;</th>
    <th >ARRIVAL&nbsp;</th>
    <th >FARE&nbsp;</th>
    
  </tr>
  <tr class="rows">
    <td>&nbsp;1.</td>

    <td>&nbsp;Mandor Express</td>
    <td>&nbsp;05:00</td>
    <td>&nbsp;11:05</td>
    <td><b>&nbsp;Rs.976</b></td>
   </tr>
  <tr class="rows">

    <td>&nbsp;2.</td>
    <td>&nbsp;Ashram Express</td>
    <td>&nbsp;04:30</td>
    <td>&nbsp;10:10</td>
    <td><b>&nbsp;Rs.1,027</b></td>
  
  </tr>
  <tr class="rows">
    <td>&nbsp;3.</td>
    <td>&nbsp;Ala Hazrat Exp</td>
    <td>&nbsp;08.00</td>
    <td>&nbsp;14:35</td>
    <td><b>&nbsp;Rs.602</b></td>

  </tr>
  <tr class="rows">
    <td>&nbsp;4.</td>
    <td>&nbsp;Malani Exp</td>
    <td>&nbsp;05:00</td>
    <td>&nbsp;11:05</td>

    <td><b>&nbsp;Rs.602</b></td>
  </tr>
  <tr class="rows">
    <td>&nbsp;5.</td>
    <td>&nbsp;Haridwar Mail</td>
    <td>&nbsp;23:15</td>

    <td>&nbsp;05:20</td>
    <td><b>&nbsp;Rs.976</b></td>
  </tr>
</table>

