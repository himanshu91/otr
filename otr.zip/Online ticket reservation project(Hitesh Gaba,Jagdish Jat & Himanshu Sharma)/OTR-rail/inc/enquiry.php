<link href="Otr.css" rel="stylesheet" type="text/css" media="screen" />
<div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
                <div style="clear: both;">&nbsp;</div>
				<h2 class="title">Enquiry Portal</h2>
                <br />
				<p class="meta">This Portal help you to enquire railway trains from one station to other with their proper details .
                The details include the arrival and departure time for the Trains with their Particular Days. It also helps you to know the status of a train wheather on time or late. One could also check availability status Reservations.  </p>
                <br />
                <div style="margin-left:150px">
                	<form action="Home.php?page=schedule" method="post">
                    <br />
                    <br/ >
                   <table> <tr><td><strong style="color:#82050B">Source:<br><br></strong></td><td><input type="text" id="source" />
					<br /><br /></td></tr>
                    <tr><td><strong style="color:#82050B">Destination:<br><br></strong></td><td><input type="text" id="destination" />
                    <br /><br /></td></tr>
		
                    <tr><td><input type="submit" value="Status" /></td> <td><input type="submit" value="Train Schedule"></td>
					</tr>
				</table>
		 </form>